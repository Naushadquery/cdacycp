package tp;

import java.util.ArrayList;

public class TP {

	public static void main(String[] args) {
		
		ArrayList al = new ArrayList<>();
		al.add("a");
		al.add("b");
		System.out.println(al);
		String s1 = "helll";
		String s2 ="helll";
		System.out.println(s1==s2);
		String s3 = new String("nau");
		String sv = s3.toUpperCase();
		System.out.println(sv);
		StringBuffer s5 = new StringBuffer("nau");
		s5.append("asf");
		System.out.println(s5);
		/*
		 * int names[] = new int[5];
		 * 
		 * names[5] = 0; for(int n : names) { System.out.println(n); }
		 * 
		 * var s = "hello"; s = "hellooooo"; s = "asdf"; var x = 1; var y = 2;
		 * System.out.println(s + y);
		 */

	}
	int i =1;
	public void tp(int i, int j) {
		int a=1;
		System.out.println(this.i);
		String s = "aa";
		Integer x = 4;
	}

}
