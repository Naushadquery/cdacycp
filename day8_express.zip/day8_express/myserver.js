var express = require('express');
var app = express();

var bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true })); 

var service = require("./service");

app.get("/",function(req,res){

    res.sendFile(__dirname+"/index.html");

});
app.get("/verify",function(req,res){
    console.log("GET MEthod")
    userid = req.query.userid
    pwd = req.query.pwd;
    service.verifyData(userid,pwd,function(result){
        console.log(result);
        res.send("<h1>Hello Express - verify"+ result +" </h1> " )
    });
});
app.post("/verify",function(req,res){
    console.log("POST MEthod")
    userid = req.body.userid
    pwd = req.body.pwd;
    service.verifyData(userid,pwd,function(result){
        console.log(result);
        res.send("<h1>Hello Express - verify"+ result +" </h1> " )
    });
});


app.listen(8989);
console.log("Started")