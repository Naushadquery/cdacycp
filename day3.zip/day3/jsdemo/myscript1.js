console.log("myscript1 loaded")


var a;
a = 10;
res = typeof(a);
console.log(res)
a = false;
res = typeof(a);
console.log(res)
b = 3;
z = a+b
console.log(z)
d = 'A';
e = "hello"
f = 2.355
g = []
h = {}
h = 3;
i = null;
var j;
k = "12"
l = 30;
console.log(k-l);
m = "40"
n = 40;

console.log(m===n);









