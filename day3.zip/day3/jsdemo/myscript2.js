
console.log("myscript2 loaded")
console.log("Hello World 11")
console.log("Hello World 22")


