var fs = require('fs');

console.log("FS Loaded")

fs.readFile("data.txt",(err,data)=>{
   if(err){
    console.log(err.message);
   }else{
    console.log(data.toString());
    fs.writeFile("beta.txt",data.toString(),function(){
        console.log("done")
    })
   }
   
});
//console.log(x.toString())
// fs.appendFile("data.txt","Ok boss",function(err){
//     console.log("data is : ")
    
// });
console.log("End of PRogram");