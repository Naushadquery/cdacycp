
function hospital(treatPatient){
    console.log(treatPatient + " under treatment");
    setTimeout(()=>{
        return "Patient " + treatPatient + " ready for discharge";
    },Math.round(50000*(Math.random())))
}

p = hospital("pares");
console.log(p)
p1 = hospital("pandeji");
console.log(p1)
console.log('Waiting at home for patient');