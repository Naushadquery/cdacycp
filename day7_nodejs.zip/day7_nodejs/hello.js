
 one =  require('./one') 

console.log("Hello World of NodeJs");

console.log(one.x+y+z);

res = sub(1,2);
console.log(res);
console.log(one.x)

r= div(20,2);
console.log(r)
