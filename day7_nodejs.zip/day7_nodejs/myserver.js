var http = require('http');
var fs = require('fs');
var url = require('url');

http.createServer(function (req, res) {

    q = url.parse(req.url,true);
    console.log(q)
    data = q.query;
    console.log(data.uname)

    // if (req.url == "/") {
    //     fs.readFile("index.html", function (err, data) {
    //         console.log(req.url)
    //         res.write(data.toString());
    //         res.end();
    //     });
    // }else if(req.url=="/emp.html"){
    //     fs.readFile("emp.html", function (err, data) {
    //         console.log(req.url)
    //         res.write(data.toString());
    //         res.end();
    //     });
    // }else{

    // }
}).listen(8888);

console.log("Server started on port 80");