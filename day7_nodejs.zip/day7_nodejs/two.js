console.log("two.js file loaded");
z =40;