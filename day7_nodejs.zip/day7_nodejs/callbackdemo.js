
function order(food,callback){
    console.log("waiting for " + food);
    setTimeout(()=>{
        if(food=="palak")
        return callback( food + " not there ");
        else{
            return callback("ok",  food + " is ready to eat","");
        }
    }, 10000);
}
order("paneer",function(e,r){
    console.log(e);
    console.log(r)
})
order("palak",function(e,r){
    console.log(e);
    console.log(r);
})
console.log("Hotel close");
