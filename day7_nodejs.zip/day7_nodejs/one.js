require('./two')
console.log("one.js file loaded");
x = 3;
y = 4;

var div = function (a, b) {
    return a / b;
}

function add(a, b) {
    return a + b;
}

sub = function (a, b) {
    return a - b;
}

module.exports = { add, x };
