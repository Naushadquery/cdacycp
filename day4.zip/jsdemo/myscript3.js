
console.log("myscript3 loaded")
sc_3 = 10;

var s3a = 50
s3a = "hello";
let s3b = 60
s3b = "hello";
const s3c = 70;
//s3c = 90;
