console.log("string demo page")

fname = 'naushad';
lname = 'naushad';
console.log(fname==lname);

nf = fname.toUpperCase();

console.log(fname);
console.log(nf);
