
console.log("myscript4 loaded")
console.log(sc_3);

console.log(s3a);

console.log(s3b);

console.log(s3c);