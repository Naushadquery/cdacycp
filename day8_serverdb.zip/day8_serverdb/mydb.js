var mysql = require("mysql")

var con = mysql.createConnection({
    host: "localhost",
    user: "cdac",
    password: "Cdacycp123#",
    database : "cdacycp"
});

con.connect(function (err) {
    if (err) throw err;
    console.log("Connected!");
});

module.exports={con}