var http = require('http');
var fs = require('fs');
var url = require('url');
var service = require("./service")

server = http.createServer((req, res) => {
    user_url = req.url;
    parsedUrl = url.parse(user_url, true);
    pathName = parsedUrl.pathname
    switch (pathName) {
        case "/": {
            fs.readFile("index.html", function (err, data) {
                res.write(data.toString());
                res.end();
            });
            break;
        }
        case "/verify": {
            q = parsedUrl.query;
            userid = q.userid;
            pwd = q.pwd;
            console.log("USer  " + userid + " " + pwd)
            service.verifyData(userid, pwd,function(resValue){
                if (resValue == 1) {
                    res.write("Welcome Password");
                    res.end();
                } else {
                    res.write("Invalid " + userid);
                    res.end();
                }
            });
            break;
        }
        default: {
            res.write("Page Not Found");
            res.end();

        }
    }


});

server.listen(8888);

console.log("Server started")

