var mydb = require("./mydb")
var result = 0;
function verifyData(userid, pwd, callback) {
    sql = "select * from loginuser where userid=" + userid;
    mydb.con.query(sql, function (err, results, fields) {
        console.log("From DB")
        if (pwd.localeCompare(results[0].pwd) == 0) {
            return callback(1)
        } else {
            return callback(0)
        }
    });
}

module.exports = { verifyData }